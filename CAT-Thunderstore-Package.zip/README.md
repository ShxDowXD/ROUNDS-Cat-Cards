
# CAT
### Created with [DeckSmith](https://rounds.thunderstore.io/package/willis81808/DeckSmith/)

A Collection of cute and silly cards featuring adorable cats! Still in development :)

## Cards


#### Happy Happy Catty

Jumping for joy!

- Bullet Speed +19%
- Attack Speed +10%
- Reload Time -20%


